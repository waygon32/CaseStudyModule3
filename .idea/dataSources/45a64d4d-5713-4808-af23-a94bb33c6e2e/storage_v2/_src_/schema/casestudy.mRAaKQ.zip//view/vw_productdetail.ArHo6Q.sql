create definer = root@localhost view vw_productdetail as
select `casestudy`.`producttype`.`typename`          AS `typeName`,
       `casestudy`.`productdetail`.`color`           AS `color`,
       `casestudy`.`productdetail`.`memory`          AS `memory`,
       `casestudy`.`productdetail`.`describeProduct` AS `describeProduct`,
       `casestudy`.`productdetail`.`price`           AS `price`,
       `casestudy`.`productdetail`.`productId`       AS `productID`
from (`casestudy`.`producttype`
         join `casestudy`.`productdetail`
              on ((`casestudy`.`productdetail`.`typeID` = `casestudy`.`producttype`.`typeID`)))
order by `casestudy`.`producttype`.`typename`;

