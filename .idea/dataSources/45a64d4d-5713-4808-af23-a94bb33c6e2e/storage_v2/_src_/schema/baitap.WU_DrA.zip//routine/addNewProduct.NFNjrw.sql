create
    definer = root@localhost procedure addNewProduct(IN pId int, IN pCode int, IN pPrice int)
begin
insert into  product (ID,productCode , productPrice ) values (pId, pCode, pPrice);
end;

